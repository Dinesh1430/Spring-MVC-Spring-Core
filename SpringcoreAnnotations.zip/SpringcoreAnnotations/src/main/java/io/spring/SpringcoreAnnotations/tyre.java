package io.spring.SpringcoreAnnotations;

public interface tyre {

	public void display();
}
