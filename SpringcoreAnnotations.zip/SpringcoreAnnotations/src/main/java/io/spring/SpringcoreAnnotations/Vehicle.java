package io.spring.SpringcoreAnnotations;

import org.springframework.stereotype.Component;

@Component
public class Vehicle implements tyre {
	
	String Company ;
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Tested Vehicle");
		
	}
	

}
