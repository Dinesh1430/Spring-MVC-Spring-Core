package io.spring.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

@Controller
public class SampleController {
	

	@RequestMapping("")
	public String add1(){
		System.out.println("Index am here");
		//View.SELECTED_CONTENT_TYPE="index";
		return "index";
	}
	@RequestMapping("add")
	public ModelAndView add(@RequestParam("t1") String n1,@RequestParam("t2") String n2,HttpServletRequest request,HttpServletResponse response){
		System.out.println("I am here");
		//String s = request.getParameter("t1") + " " + request.getParameter("t2");
		String s = n1 + " " + n2;
		ModelAndView m = new ModelAndView();
		m.setViewName("greetings");
		m.addObject("result", s);
		return m;
	}

}
